package com.java.payXpert;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.Test;

import com.java.payXpert.model.Employee;

public class EmployeeTest {

	@Test
	public void testConstructors() throws ParseException {
		
		Employee employee = new Employee();
		assertNotNull(employee);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Employee emp = new Employee(1, "Anu", "Priya", sdf.parse("2000-10-10"), "FEMALE", "anu@gmail.com", "9933993399", "Chennai", "SWE",  sdf.parse("2024-05-01"), sdf.parse("2055-10-10"));
		assertEquals(1, emp.getEmployeeId());
		assertEquals("Anu", emp.getFirstName());
		assertEquals("Priya", emp.getLastName());
		assertEquals(sdf.parse("2000-10-10"), emp.getDob());
		assertEquals("FEMALE", emp.getGender());
		assertEquals("anu@gmail.com", emp.getEmail());
		assertEquals("9933993399", emp.getPhoneNumber());
		assertEquals("Chennai", emp.getAddress());
		assertEquals("SWE", emp.getPosition());
		assertEquals(sdf.parse("2024-05-01"), emp.getJoiningDate());
		assertEquals(sdf.parse("2055-10-10"), emp.getTerminationDate());
		
	}
	
	@Test
	public void testGettersAndSetters() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Employee employee = new Employee();
		employee.setEmployeeId(1);
		employee.setFirstName("Anu");
		employee.setLastName("Priya");
		employee.setGender("FEMALE");
		employee.setEmail("anu@gmail.com");
		employee.setPhoneNumber("9933993399");
		employee.setAddress("Chennai");
		employee.setPosition("SWE");
		employee.setDob(sdf.parse("2000-10-10"));
		employee.setJoiningDate(sdf.parse("2024-05-01"));
		employee.setTerminationDate(sdf.parse("2055-10-10"));
		assertEquals(1, employee.getEmployeeId());
		assertEquals("Anu", employee.getFirstName());
		assertEquals("Priya", employee.getLastName());
		assertEquals("FEMALE", employee.getGender());
		assertEquals("anu@gmail.com", employee.getEmail());
		assertEquals("9933993399", employee.getPhoneNumber());
		assertEquals("Chennai", employee.getAddress());
		assertEquals("SWE", employee.getPosition());
		assertEquals(sdf.parse("2000-10-10"), employee.getDob());
		assertEquals(sdf.parse("2024-05-01"), employee.getJoiningDate());
		assertEquals(sdf.parse("2055-10-10"), employee.getTerminationDate());
	}
	
	@Test
	public void testToString() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Employee emp1 = new Employee(1, "Anu", "Priya", sdf.parse("2000-10-10"), "FEMALE", "anu@gmail.com", "9933993399", "Chennai", "SWE", sdf.parse("2024-05-01"), sdf.parse("2055-10-10"));
		String result = "Employee [employeeId=1, firstName=Anu, lastName=Priya, dob=Tue Oct 10 00:00:00 IST 2000, gender=FEMALE, "
			+ "email=anu@gmail.com, phoneNumber=9933993399, address=Chennai, position=SWE, "
			+ "joiningDate=Wed May 01 00:00:00 IST 2024, "
			+ "terminationDate=Sun Oct 10 00:00:00 IST 2055]";
		assertEquals(emp1.toString(), result);
	}
	
	@Test
	public void testHashCode() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Employee emp1 = new Employee(1, "Anu", "Priya", sdf.parse("2000-10-10"), "FEMALE", "anu@gmail.com", 
				"9933993399", "Chennai", "SWE",  sdf.parse("2024-05-01"), sdf.parse("2055-10-10"));
		Employee emp2 = new Employee(1, "Anu", "Priya", sdf.parse("2000-10-10"), "FEMALE", "anu@gmail.com", 
				"9933993399", "Chennai", "SWE",  sdf.parse("2024-05-01"), sdf.parse("2055-10-10"));
		assertEquals(emp1.hashCode(), emp2.hashCode());
	}
	
	@Test
	public void testEquals() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Employee emp1 = new Employee(1, "Anu", "Priya", sdf.parse("2000-10-10"), "FEMALE", "anu@gmail.com", 
				"9933993399", "Chennai", "SWE",  sdf.parse("2024-05-01"), sdf.parse("2055-10-10"));
		Employee emp2 = new Employee(1, "Anu", "Priya", sdf.parse("2000-10-10"), "FEMALE", "anu@gmail.com", 
				"9933993399", "Chennai", "SWE",  sdf.parse("2024-05-01"), sdf.parse("2055-10-10"));
		Employee emp3 = new Employee(1, "Anu", "Priya", sdf.parse("2000-10-10"), "FEMALE", "anu@gmail.com", 
				"9933993399", "Bangalore", "SWE",  sdf.parse("2024-05-01"), sdf.parse("2055-10-10"));
		assertTrue(emp1.equals(emp2));
		assertFalse(emp1.equals(emp3));
	}
	
	@Test
	public void testCalculateAge() throws ParseException 
	{
		Employee employee = new Employee();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		assertEquals(21, employee.CalculateAge(sdf.parse("2002-11-02")));
	}

}
