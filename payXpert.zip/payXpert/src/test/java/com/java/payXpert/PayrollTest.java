package com.java.payXpert;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.Test;

import com.java.payXpert.model.Payroll;

public class PayrollTest {
	
	@Test
	public void testConstructors() throws ParseException
	{
		Payroll payroll = new Payroll();
		assertNotNull(payroll);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Payroll pay = new Payroll(1,1,sdf.parse("2020-03-26"),sdf.parse("2020-04-26"),50000.00,3000.00,1000.00,52000.00);
		assertEquals(1,pay.getPayrollId());
		assertEquals(1,pay.getEmployeeId());
		assertEquals(sdf.parse("2020-03-26"),pay.getPayPeriodStartDate());
		assertEquals(sdf.parse("2020-04-26"),pay.getPayPeriodEndDate());
		assertEquals(50000.00,pay.getBasicSalary(),2);
		assertEquals(3000.00,pay.getOverTimePay(),2);
		assertEquals(1000.00,pay.getDeductions(),2);
		assertEquals(52000.00,pay.getNetSalary(),2);
	}

	@Test
	public void testGettersAndSetters() throws ParseException
	{
		Payroll pay = new Payroll();
		pay.setPayrollId(1);
		pay.setEmployeeId(1);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		pay.setPayPeriodStartDate(sdf.parse("2020-03-26"));
		pay.setPayPeriodEndDate(sdf.parse("2020-04-26"));
		pay.setBasicSalary(50000.00);
		pay.setOverTimePay(3000.00);
		pay.setDeductions(1000.00);
		pay.setNetSalary(52000.00);
		assertEquals(1, pay.getPayrollId());
		assertEquals(1, pay.getEmployeeId());
		assertEquals(sdf.parse("2020-03-26"),pay.getPayPeriodStartDate());
		assertEquals(sdf.parse("2020-04-26"),pay.getPayPeriodEndDate());
		assertEquals(50000.00,pay.getBasicSalary(),2);
		assertEquals(3000.00,pay.getOverTimePay(),2);
		assertEquals(1000.00,pay.getDeductions(),2);
		assertEquals(52000.00,pay.getNetSalary(),2);
	}
	
	@Test
	public void testToString() throws ParseException
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Payroll pay = new Payroll(1,1,sdf.parse("2020-03-26"),sdf.parse("2020-04-26"),50000.00,3000.00,1000.00,52000.00);
		String result = "Payroll [payrollId=1, employeeId=1, payPeriodStartDate=Thu Mar 26 00:00:00 IST 2020, payPeriodEndDate=Sun Apr 26 00:00:00 IST 2020, basicSalary=50000.0, overTimePay=3000.0, Deductions=1000.0, netSalary=52000.0]";
		assertEquals(result, pay.toString());
	}
	
	@Test
	public void testHashCode() throws ParseException
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Payroll payroll1 = new Payroll(1,1,sdf.parse("2020-03-26"),sdf.parse("2020-04-26"),50000.00,3000.00,1000.00,52000.00);
		Payroll payroll2 = new Payroll(1,1,sdf.parse("2020-03-26"),sdf.parse("2020-04-26"),50000.00,3000.00,1000.00,52000.00);		
		assertEquals(payroll1.hashCode(), payroll2.hashCode());
	}
	
	@Test
	public void testEquals() throws ParseException
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Payroll payroll1 = new Payroll(1,1,sdf.parse("2020-03-26"),sdf.parse("2020-04-26"),50000.00,3000.00,1000.00,52000.00);
		Payroll payroll2 = new Payroll(1,1,sdf.parse("2020-03-26"),sdf.parse("2020-04-26"),50000.00,3000.00,1000.00,52000.00);		
		Payroll payroll3 = new Payroll(2,3,sdf.parse("2020-03-26"),sdf.parse("2020-04-26"),50000.00,3000.00,1000.00,52000.00);				
		assertTrue(payroll1.equals(payroll2));
		assertFalse(payroll1.equals(payroll3));
	}
}







