package com.java.payXpert;

import static org.junit.Assert.*;

import org.junit.Test;

import com.java.payXpert.model.Tax;

public class TaxTest {
	
	@Test
	public void testTaxTest()
	{
		Tax tax1 = new Tax();
		assertNotNull(tax1);
		Tax tax = new Tax(5,5,"2023",47800.00,7200.00);
		assertEquals(5, tax.getTaxId());
		assertEquals(5, tax.getEmployeeId());
		assertEquals("2023", tax.getTaxYear());
		assertEquals(47800.00, tax.getTaxableIncome(), 2);
		assertEquals(7200.00, tax.getTaxAmount(), 2);
	}
	
	@Test
	public void testGettersAndSetters()
	{
		Tax tax = new Tax();
		tax.setTaxId(5);
		tax.setEmployeeId(5);
		tax.setTaxYear("2023");
		tax.setTaxableIncome(47800.00);
		tax.setTaxAmount(7200.00);
		assertEquals(5, tax.getTaxId());
		assertEquals(5, tax.getEmployeeId());
		assertEquals("2023", tax.getTaxYear());
		assertEquals(47800.00, tax.getTaxableIncome(), 2);
		assertEquals(7200.00, tax.getTaxAmount(), 2);
	}
	
	@Test
	public void testToString()
	{
		Tax tax = new Tax(5,5,"2023",47800.00,7200.00);
		String result = "Tax [taxId=5, employeeId=5, taxYear=2023, taxableIncome=47800.0, taxAmount=7200.0]";
		assertEquals(result, tax.toString());
	}
	
	@Test
	public void testHashCode()
	{
		Tax tax1 = new Tax(5,5,"2023",47800.00,7200.00);
		Tax tax2 = new Tax(5,5,"2023",47800.00,7200.00);
		assertEquals(tax1.hashCode(), tax2.hashCode());
	}
	
	
	@Test
	public void testEquals()
	{
		Tax tax1 = new Tax(5,5,"2023",47800.00,7200.00);
		Tax tax2 = new Tax(5,5,"2023",47800.00,7200.00);
		Tax tax3 = new Tax(1,1,"2023",47800.00,7200.00);
		assertTrue(tax1.equals(tax2));
		assertFalse(tax1.equals(tax3));
	}

}
