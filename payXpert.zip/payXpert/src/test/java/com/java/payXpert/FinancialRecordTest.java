package com.java.payXpert;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.Test;

import com.java.payXpert.model.FinancialRecord;

public class FinancialRecordTest {
	
	@Test
	public void testConstructors() throws ParseException
	{
		FinancialRecord finance1 = new FinancialRecord();
		assertNotNull(finance1);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		FinancialRecord finance = new FinancialRecord(2, 2, sdf.parse("2024-04-30"), "bonus",10000.00, "income");
		assertEquals(2, finance.getRecordId());
		assertEquals(2, finance.getEmployeeId());
		assertEquals(sdf.parse("2024-04-30"), finance.getRecordDate());
		assertEquals("bonus", finance.getDescription());
		assertEquals(10000.00, finance.getAmount(), 2);
		assertEquals("income", finance.getRecordType());
	}
	
	@Test
	public void testGettersAndSetters() throws ParseException
	{
		FinancialRecord finance = new FinancialRecord();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		finance.setRecordId(2);
		finance.setEmployeeId(2);
		finance.setRecordDate(sdf.parse("2024-04-30"));
		finance.setDescription("bonus");
		finance.setAmount(10000.00);
		finance.setRecordType("income");
		assertEquals(2, finance.getRecordId());
		assertEquals(2, finance.getEmployeeId());
		assertEquals(sdf.parse("2024-04-30"), finance.getRecordDate());
		assertEquals("bonus", finance.getDescription());
		assertEquals(10000.00, finance.getAmount(), 2);
		assertEquals("income", finance.getRecordType());
	}
	
	@Test
	public void testToString() throws ParseException
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		FinancialRecord finance = new FinancialRecord(2, 2, sdf.parse("2024-04-30"), "bonus",10000.00, "income");
		String result = "FinancialRecord [recordId=2, employeeId=2, recordDate=Tue Apr 30 00:00:00 IST 2024, description=bonus, amount=10000.0, recordType=income]";
		assertEquals(result, finance.toString());
	}
	
	@Test
	public void testHashCode() throws ParseException
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		FinancialRecord finance1 = new FinancialRecord(2, 2, sdf.parse("2024-04-30"), "bonus",10000.00, "income");
		FinancialRecord finance2 = new FinancialRecord(2, 2, sdf.parse("2024-04-30"), "bonus",10000.00, "income");
		assertEquals(finance1.hashCode(), finance2.hashCode());
	}
	
	@Test
	public void testEquals() throws ParseException
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		FinancialRecord finance1 = new FinancialRecord(2, 2, sdf.parse("2024-04-30"), "bonus",10000.00, "income");
		FinancialRecord finance2 = new FinancialRecord(2, 2, sdf.parse("2024-04-30"), "bonus",10000.00, "income");
		FinancialRecord finance3 = new FinancialRecord(2, 4, sdf.parse("2024-04-30"), "bonus",10000.00, "income");
		assertTrue(finance1.equals(finance2));
		assertFalse(finance1.equals(finance3));
	}
	
	
	
	
	

}
