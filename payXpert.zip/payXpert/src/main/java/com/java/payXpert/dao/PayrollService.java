package com.java.payXpert.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

import com.java.payXpert.model.Payroll;
import com.java.payXpert.util.DBConnUtil;
import com.java.payXpert.util.DBPropertyUtil;

public class PayrollService implements IPayrollService {
	
	Connection con;
	PreparedStatement pst;

	@Override
	public Payroll GetPayrollById(int payrollId) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM payroll WHERE payrollId = ?";
		pst = con.prepareStatement(query);
		pst.setInt(1, payrollId);
		ResultSet rs = pst.executeQuery();
		Payroll payroll = null;
		if(rs.next())
		{
			payroll = new Payroll();
			payroll.setPayrollId(rs.getInt("payrollId"));
			payroll.setEmployeeId(rs.getInt("employeeID"));
			payroll.setPayPeriodStartDate(rs.getDate("payPeriodStartDate"));
			payroll.setPayPeriodEndDate(rs.getDate("payPeriodEndDate"));
			payroll.setBasicSalary(rs.getDouble("basicSalary"));
			payroll.setOverTimePay(rs.getDouble("overTimePay"));
			payroll.setDeductions(rs.getDouble("Deductions"));
			payroll.setNetSalary(rs.getDouble("netSalary"));
			
		}
		return payroll;
	}

	@Override
	public List<Payroll> GetPayrollsForEmployee(int employeeId) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM payroll WHERE employeeId = ?";
		pst = con.prepareStatement(query);
		pst.setInt(1, employeeId);
		ResultSet rs = pst.executeQuery();
		List<Payroll> payrollList = new ArrayList<Payroll> ();
		Payroll payroll = null;
		while(rs.next())
		{
			payroll = new Payroll();
			payroll.setPayrollId(rs.getInt("payrollId"));
			payroll.setEmployeeId(rs.getInt("employeeID"));
			payroll.setPayPeriodStartDate(rs.getDate("payPeriodStartDate"));
			payroll.setPayPeriodEndDate(rs.getDate("payPeriodEndDate"));
			payroll.setBasicSalary(rs.getDouble("basicSalary"));
			payroll.setOverTimePay(rs.getDouble("overTimePay"));
			payroll.setDeductions(rs.getDouble("Deductions"));
			payroll.setNetSalary(rs.getDouble("netSalary"));
			payrollList.add(payroll);
			
		}
		return payrollList;	
	}

	@Override
	public List<Payroll> GetPayroolsForPeriod(Date startDate, Date endDate) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM payroll WHERE payPeriodStartDate = ? AND payPeriodEndDate = ?";
		pst = con.prepareStatement(query);
		pst.setDate(1, new java.sql.Date(startDate.getTime()));
		pst.setDate(2, new java.sql.Date(endDate.getTime()));
		ResultSet rs = pst.executeQuery();
		List<Payroll> payrollList = new ArrayList<Payroll> ();
		Payroll payroll = null;
		while(rs.next())
		{
			payroll = new Payroll();
			payroll.setPayrollId(rs.getInt("payrollId"));
			payroll.setEmployeeId(rs.getInt("employeeID"));
			payroll.setPayPeriodStartDate(rs.getDate("payPeriodStartDate"));
			payroll.setPayPeriodEndDate(rs.getDate("payPeriodEndDate"));
			payroll.setBasicSalary(rs.getDouble("basicSalary"));
			payroll.setOverTimePay(rs.getDouble("overTimePay"));
			payroll.setDeductions(rs.getDouble("Deductions"));
			payroll.setNetSalary(rs.getDouble("netSalary"));
			payrollList.add(payroll);
			
		}
		return payrollList;		
	}

	@Override
	public Payroll GeneratePayRoll(int employeeId, Date startDate, Date endDate) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM payroll WHERE payrollId = ? AND payPeriodStartDate = ? AND payPeriodEndDate = ?";
		pst = con.prepareStatement(query);
		pst.setInt(1, employeeId);
		pst.setDate(2, new java.sql.Date(startDate.getTime()));
		pst.setDate(3, new java.sql.Date(endDate.getTime()));
		ResultSet rs = pst.executeQuery();
		Payroll payroll = null;
		if(rs.next())
		{
			payroll = new Payroll();
			payroll.setPayrollId(rs.getInt("payrollId"));
			payroll.setEmployeeId(rs.getInt("employeeID"));
			payroll.setPayPeriodStartDate(rs.getDate("payPeriodStartDate"));
			payroll.setPayPeriodEndDate(rs.getDate("payPeriodEndDate"));
			payroll.setBasicSalary(rs.getDouble("basicSalary"));
			payroll.setOverTimePay(rs.getDouble("overTimePay"));
			payroll.setDeductions(rs.getDouble("Deductions"));
			payroll.setNetSalary(rs.getDouble("netSalary"));
			
		}
		return payroll;
		
	}
	


}
