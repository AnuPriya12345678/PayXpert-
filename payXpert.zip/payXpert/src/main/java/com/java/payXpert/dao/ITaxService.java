package com.java.payXpert.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.payXpert.model.Tax;

public interface ITaxService {
	
	Double CalculateTax(int employeeId, String taxYear) throws ClassNotFoundException, SQLException;
	Tax GetTaxById(int taxId) throws ClassNotFoundException, SQLException;
	List<Tax> GetTaxesForEmployee(int employeeId) throws ClassNotFoundException, SQLException;
	List<Tax> GetTaxesForYear(String taxYear) throws ClassNotFoundException, SQLException;

}
