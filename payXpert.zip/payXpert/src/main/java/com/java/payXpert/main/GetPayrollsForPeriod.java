package com.java.payXpert.main;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.java.payXpert.dao.IPayrollService;
import com.java.payXpert.dao.PayrollService;
import com.java.payXpert.model.Payroll;

public class GetPayrollsForPeriod {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the payroll start date (yyyy-MM-dd) : ");
		String startDateStr = sc.next();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate = null;
		try {
			startDate = sdf.parse(startDateStr);
		} 
		catch (ParseException e) {
			e.printStackTrace();
			System.exit(1);
		}
		System.out.println("Enter the payroll end date : ");
		String endDateStr = sc.next();
		Date endDate = null;
		try {
			endDate = sdf.parse(endDateStr);
		} 
		catch (ParseException e) {
			e.printStackTrace();
			System.exit(1);
		}
		IPayrollService ps = new PayrollService();
		try {
			List<Payroll> payrollList = ps.GetPayroolsForPeriod(startDate, endDate);
			if(payrollList.size() == 0)
				System.out.println("Record not found ...");
			else
			{
				for(Payroll payroll : payrollList)
					System.out.println(payroll);
			}
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

}
