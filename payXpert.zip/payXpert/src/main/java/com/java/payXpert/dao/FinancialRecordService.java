package com.java.payXpert.dao;

import java.sql.Connection; 
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.java.payXpert.model.FinancialRecord;
import com.java.payXpert.util.DBConnUtil;
import com.java.payXpert.util.DBPropertyUtil;

public class FinancialRecordService implements IFinancialRecordService {
	
	Connection con;
	PreparedStatement pst;

	@Override
	public FinancialRecord GetFinancialRecordById(int recordId) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM finance WHERE recordId = ?";
		pst = con.prepareStatement(query);
		pst.setInt(1, recordId);
		ResultSet rs = pst.executeQuery();
		FinancialRecord financialRecord = null;
		if(rs.next())
		{
			financialRecord = new FinancialRecord();
			financialRecord.setRecordId(rs.getInt("recordId"));
			financialRecord.setEmployeeId(rs.getInt("employeeId"));
			financialRecord.setRecordDate(rs.getDate("recordDate"));
			financialRecord.setDescription(rs.getString("Description"));
			financialRecord.setAmount(rs.getDouble("amount"));
			financialRecord.setRecordType(rs.getString("recordType"));
		}
		return financialRecord;
		
	}

	@Override
	public List<FinancialRecord> GetFinancialRecordsForEmployee(int employeeId) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM finance WHERE employeeId = ?";
		pst = con.prepareStatement(query);
		pst.setInt(1, employeeId);
		ResultSet rs = pst.executeQuery();
		List<FinancialRecord> financialRecordList = new ArrayList<FinancialRecord> ();
		FinancialRecord financialRecord = null;
		while(rs.next())
		{
			financialRecord = new FinancialRecord();
			financialRecord.setRecordId(rs.getInt("recordId"));
			financialRecord.setEmployeeId(rs.getInt("employeeId"));
			financialRecord.setRecordDate(rs.getDate("recordDate"));
			financialRecord.setDescription(rs.getString("Description"));
			financialRecord.setAmount(rs.getDouble("amount"));
			financialRecord.setRecordType(rs.getString("recordType"));
			financialRecordList.add(financialRecord);
		}
		return financialRecordList;
		
	}

	@Override
	public List<FinancialRecord> GetFinancialRecordsForDate(Date recordDate) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM finance WHERE recordDate = ?";
		pst = con.prepareStatement(query);
		pst.setDate(1, new java.sql.Date(recordDate.getTime()));
		ResultSet rs = pst.executeQuery();
		List<FinancialRecord> financialRecordList = new ArrayList<FinancialRecord> ();
		FinancialRecord financialRecord = null;
		while(rs.next())
		{
			financialRecord = new FinancialRecord();
			financialRecord.setRecordId(rs.getInt("recordId"));
			financialRecord.setEmployeeId(rs.getInt("employeeId"));
			financialRecord.setRecordDate(rs.getDate("recordDate"));
			financialRecord.setDescription(rs.getString("Description"));
			financialRecord.setAmount(rs.getDouble("amount"));
			financialRecord.setRecordType(rs.getString("recordType"));
			financialRecordList.add(financialRecord);
		}
		return financialRecordList;
		
	}

	@Override
	public String AddFinancialRecord(int employeeId, String description, Double amount, String recordType) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "INSERT INTO finance VALUES(?,?,?,?,?,?)";
		pst = con.prepareStatement(query);
		pst.setInt(1, GenerateRecordId());
		pst.setInt(2, employeeId);
		Date date = new java.util.Date();
		pst.setDate(3, new java.sql.Date(date.getTime()));
		pst.setString(4, description);
		pst.setDouble(5, amount);
		pst.setString(6, recordType);
		pst.executeUpdate();
		return "Inertion successful ...";
		
	}
	
	public static int GenerateRecordId() throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		Connection con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT max(recordId) FROM finance";
		PreparedStatement pst = con.prepareStatement(query);
		ResultSet rs = pst.executeQuery();
		rs.next();
		return rs.getInt(1)+1;	
	}

}
