package com.java.payXpert.model;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

public class FinancialRecord {

	private int recordId;
	private int employeeId;
	private Date recordDate;
	private String description;
	private Double amount;
	private String recordType;
	
	public FinancialRecord() {
		
	}

	public FinancialRecord(int recordId, int employeeId, Date recordDate, String description, Double amount,
			String recordType) {
		super();
		this.recordId = recordId;
		this.employeeId = employeeId;
		this.recordDate = recordDate;
		this.description = description;
		this.amount = amount;
		this.recordType = recordType;
	}

	public int getRecordId() {
		return recordId;
	}

	public void setRecordId(int recordId) {
		this.recordId = recordId;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public Date getRecordDate() {
		return recordDate;
	}

	public void setRecordDate(Date recordDate) {
		this.recordDate = recordDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	@Override
	public String toString() {
		return "FinancialRecord [recordId=" + recordId + ", employeeId=" + employeeId + ", recordDate=" + recordDate
				+ ", description=" + description + ", amount=" + amount + ", recordType=" + recordType + "]";
	}
	
	@Override
	public int hashCode()
	{
		return Objects.hash(recordId, employeeId, recordDate, description, amount, recordType);
	}
	
	@Override
	public boolean equals(Object obj)
	{
		FinancialRecord finance = (FinancialRecord) obj;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		if(finance.getRecordId() == recordId && finance.getEmployeeId() == employeeId
				&& finance.getRecordDate().compareTo(recordDate) == 0 
				&& finance.getDescription() == description && Double.compare(finance.getAmount(), amount) == 0
				&& finance.getRecordType() == recordType
				)
		{
			return true;
		}
		return false;
	}
	
}
