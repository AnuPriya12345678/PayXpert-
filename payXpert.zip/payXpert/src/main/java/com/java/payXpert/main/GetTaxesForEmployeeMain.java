package com.java.payXpert.main;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.java.payXpert.dao.ITaxService;
import com.java.payXpert.dao.TaxService;
import com.java.payXpert.exception.EmployeeNotFoundException;
import com.java.payXpert.model.Tax;

public class GetTaxesForEmployeeMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the employee ID : ");
		int employeeId = -1;
		try{
			employeeId = sc.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.err.println("Expected input type was integer");
			System.exit(1);
		}
		ITaxService ts = new TaxService();
		try {
			List<Tax> taxList = ts.GetTaxesForEmployee(employeeId);
			if(taxList.size() == 0)
				throw new EmployeeNotFoundException("There is no employee having employeeId as "+employeeId);
			else
			{
				for(Tax tax : taxList)
					System.out.println(tax);
			}
			
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} 
		catch (EmployeeNotFoundException e) {
			System.err.println(e.getMessage());
		}
		
	}

}
