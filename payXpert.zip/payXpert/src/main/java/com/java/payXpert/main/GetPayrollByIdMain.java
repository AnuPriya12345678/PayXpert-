package com.java.payXpert.main;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.java.payXpert.dao.PayrollService;
import com.java.payXpert.dao.IPayrollService;
import com.java.payXpert.model.Payroll;

public class GetPayrollByIdMain {

    public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the payroll ID : ");
		int payrollId = -1;
		try {
			payrollId  = sc.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.err.println("Expected input type was integer");
			System.exit(1);
		}
		IPayrollService ps = new PayrollService();
		try {
			Payroll payroll = ps.GetPayrollById(payrollId);
			if(payroll != null)
			    System.out.println(payroll);
			else
				System.err.println("Record not found ...");
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
	}
	
}
