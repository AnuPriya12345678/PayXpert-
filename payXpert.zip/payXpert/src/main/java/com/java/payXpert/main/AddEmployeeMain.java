package com.java.payXpert.main;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.java.payXpert.dao.EmployeeService;
import com.java.payXpert.dao.IEmployeeService;
import com.java.payXpert.exception.InvalidInputException;
import com.java.payXpert.model.Employee;

public class AddEmployeeMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Employee employee = new Employee();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		System.out.println("Enter Employee Id : ");
		employee.setEmployeeId(sc.nextInt());
		System.out.println("Enter First Name : ");
		employee.setFirstName(sc.next());
		System.out.println("Enter Last Name : ");
		employee.setLastName(sc.next());
		System.out.println("Enter Date-of-birth (yyyy-MM-dd) : ");
		String dobStr = sc.next();
		Date dob = null;
		try {
			dob = sdf.parse(dobStr);
		}
		catch (ParseException e) {
			e.printStackTrace();
			System.exit(1);
		}
		employee.setDob(dob);
		System.out.println("Enter gender : ");
		employee.setGender(sc.next());
		System.out.println("Enter email : ");
		employee.setEmail(sc.next());
		System.out.println("Enter Phone Number : ");
		employee.setPhoneNumber(sc.next());
		System.out.println("Enter address : ");
		employee.setAddress(sc.next());
		System.out.println("Enter Position : ");
		employee.setPosition(sc.next());
		System.out.println("Enter Joining Date (yyyy-MM-dd) ");
		String joiningDateStr = sc.next();
		Date joiningDate = null;
		try {
			joiningDate = sdf.parse(joiningDateStr);
		} 
		catch (ParseException e) {
			e.printStackTrace();
			System.exit(1);		}
		employee.setJoiningDate(joiningDate);
		System.out.println("Enter Termination Date (yyyy-MM-dd) ");
		String terminationDateStr = sc.next();
		Date terminationDate = null;
		try {
			terminationDate = sdf.parse(terminationDateStr);
		} 
		catch (ParseException e) {
			e.printStackTrace();
			System.exit(1);
		}
		employee.setTerminationDate(terminationDate);
	
		IEmployeeService es = new EmployeeService();
		try {
			String msg = es.AddEmployee(employee);
			System.out.println(msg);
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} 
		
	}

}
