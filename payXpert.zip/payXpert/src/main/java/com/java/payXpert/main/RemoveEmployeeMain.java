package com.java.payXpert.main;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.java.payXpert.dao.EmployeeService;
import com.java.payXpert.dao.IEmployeeService;
import com.java.payXpert.exception.EmployeeNotFoundException;
import com.java.payXpert.model.Employee;

public class RemoveEmployeeMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee Id : ");
		int employeeId = -1;
		try {
			employeeId = sc.nextInt();
		}
	    catch(InputMismatchException e)
		{
	    	System.err.println("Expected input type was integer");
	    	System.exit(0);
		}
		
		IEmployeeService es = new EmployeeService();
		try {
			String msg = es.RemoveEmployee(employeeId);
			if(msg.equals("Invalid employee Id"))
				throw new EmployeeNotFoundException("There is no employee having employeeId as "+employeeId);
			else
				System.out.println(msg);
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} 
		catch (EmployeeNotFoundException e) {
			System.err.println(e.getMessage());
		}
		
	}

}
