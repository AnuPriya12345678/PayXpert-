package com.java.payXpert.main;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.java.payXpert.dao.FinancialRecordService;
import com.java.payXpert.dao.IFinancialRecordService;
import com.java.payXpert.dao.IPayrollService;
import com.java.payXpert.dao.PayrollService;
import com.java.payXpert.exception.PayrollGenerationException;
import com.java.payXpert.model.FinancialRecord;
import com.java.payXpert.model.Payroll;

public class GeneratePayRollMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee Id : ");
		int employeeId = -1;
		try{
			employeeId = sc.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.err.println("Expected input type was integer");
			System.exit(1);
		}
		System.out.println("Enter the start date in the format yyyy-MM-dd");
		String startDateStr = sc.next();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");  
		Date startDate = null;
		try {
			 startDate =   sdf.parse(startDateStr);
		} 
		catch (ParseException e) {
			e.printStackTrace();
			System.exit(1);
		}  
		System.out.println("Enter the start date in the format yyyy-MM-dd");
		String endDateStr = sc.next();
		Date endDate = null;
		try {
			 endDate =   sdf.parse(endDateStr);
		} 
		catch (ParseException e) {
			e.printStackTrace();
			System.exit(1);
		}  
		IPayrollService ps = new PayrollService();
		try {
			Payroll payroll = ps.GeneratePayRoll(employeeId, startDate, endDate);
			if(payroll != null)
				System.out.println(payroll);
			else
				throw new PayrollGenerationException("Payroll cannot be generated");
			
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();    
		
       } 
		catch (PayrollGenerationException e) {
			System.err.println(e.getMessage());
		}   

	}

}
