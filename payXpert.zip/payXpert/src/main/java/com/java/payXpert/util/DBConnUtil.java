package com.java.payXpert.util;

import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.SQLException;
import java.util.ResourceBundle;

public class DBConnUtil {
	
	public static Connection getConnection(String connectionString) throws SQLException, ClassNotFoundException
	{
		ResourceBundle rb = ResourceBundle.getBundle("db");
		String driver = rb.getString("driver");
		String userName = rb.getString("userName");
		String passWord = rb.getString("passWord");
		Class.forName(driver);
		Connection con = DriverManager.getConnection(connectionString,userName,passWord);
		return con;
	}

	
}
