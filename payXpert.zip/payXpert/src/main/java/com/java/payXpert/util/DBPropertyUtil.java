package com.java.payXpert.util;

import java.util.ResourceBundle;

public class DBPropertyUtil {
		
		public static String getConnectonString(String propertyFileName)
		{
			ResourceBundle rb = ResourceBundle.getBundle(propertyFileName);
			String connectionString = rb.getString("url");
			return connectionString;
		}

	}

