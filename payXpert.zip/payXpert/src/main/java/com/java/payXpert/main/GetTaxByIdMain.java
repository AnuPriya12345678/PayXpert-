package com.java.payXpert.main;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.java.payXpert.dao.IPayrollService;
import com.java.payXpert.dao.PayrollService;
import com.java.payXpert.dao.TaxService;
import com.java.payXpert.exception.InvalidInputException;
import com.java.payXpert.model.Payroll;
import com.java.payXpert.model.Tax;
import com.java.payXpert.dao.ITaxService;

public class GetTaxByIdMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the tax ID : ");
		int taxId = -1;
		try{
			taxId = sc.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.err.println("Expected input type was integer");
			System.exit(1);
		}
		ITaxService ts = new TaxService();
		try {
			Tax tax = ts.GetTaxById(taxId);
			if(tax != null)
			    System.out.println(tax);
			else
				throw new InvalidInputException("Input data is invalid");
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} 
		catch (InvalidInputException e) {
			System.err.println(e.getMessage());
		}
		
	}

}
