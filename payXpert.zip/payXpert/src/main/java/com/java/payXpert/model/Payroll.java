package com.java.payXpert.model;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

public class Payroll {
	
	private int payrollId;
	private int employeeId;
	private Date payPeriodStartDate;
	private Date payPeriodEndDate;
	private Double basicSalary;
	private Double overTimePay;
	private Double Deductions;
	private Double netSalary;
	
	public Payroll() {
		
	}

	public Payroll(int payrollId, int employeeId, Date payPeriodStartDate, Date payPeriodEndDate,
			Double basicSalary, Double overTimePay, Double deductions, Double netSalary) {
		super();
		this.payrollId = payrollId;
		this.employeeId = employeeId;
		this.payPeriodStartDate = payPeriodStartDate;
		this.payPeriodEndDate = payPeriodEndDate;
		this.basicSalary = basicSalary;
		this.overTimePay = overTimePay;
		Deductions = deductions;
		this.netSalary = netSalary;
	}

	public int getPayrollId() {
		return payrollId;
	}

	public void setPayrollId(int payrollId) {
		this.payrollId = payrollId;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public Date getPayPeriodStartDate() {
		return payPeriodStartDate;
	}

	public void setPayPeriodStartDate(Date payPeriodStartDate) {
		this.payPeriodStartDate = payPeriodStartDate;
	}

	public Date getPayPeriodEndDate() {
		return payPeriodEndDate;
	}

	public void setPayPeriodEndDate(Date payPeriodEndDate) {
		this.payPeriodEndDate = payPeriodEndDate;
	}

	public Double getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(Double basicSalary) {
		this.basicSalary = basicSalary;
	}

	public Double getOverTimePay() {
		return overTimePay;
	}

	public void setOverTimePay(Double overTimePay) {
		this.overTimePay = overTimePay;
	}

	public Double getDeductions() {
		return Deductions;
	}

	public void setDeductions(Double deductions) {
		Deductions = deductions;
	}

	public Double getNetSalary() {
		return netSalary;
	}

	public void setNetSalary(Double netSalary) {
		this.netSalary = netSalary;
	}

	@Override
	public String toString() {
		return "Payroll [payrollId=" + payrollId + ", employeeId=" + employeeId + ", payPeriodStartDate="
				+ payPeriodStartDate + ", payPeriodEndDate=" + payPeriodEndDate + ", basicSalary=" + basicSalary
				+ ", overTimePay=" + overTimePay + ", Deductions=" + Deductions + ", netSalary=" + netSalary + "]";
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(payrollId, employeeId, payPeriodStartDate, payPeriodEndDate, basicSalary, overTimePay, Deductions, netSalary);
	}
	
	@Override
	public boolean equals(Object obj) {
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Payroll pay = (Payroll) obj;
		if(pay.getPayrollId() == payrollId && pay.getEmployeeId() == employeeId 
				&& pay.payPeriodStartDate.compareTo(payPeriodStartDate) == 0
				&& pay.payPeriodEndDate.compareTo(payPeriodEndDate) == 0
				&& Double.compare(pay.getBasicSalary(), basicSalary) == 0
			    && Double.compare(pay.getOverTimePay(), overTimePay) == 0
                && Double.compare(pay.getDeductions(), Deductions) == 0
                && Double.compare(pay.getNetSalary(), netSalary) == 0 
           )
		{
			return true;
		}
		return false;
		
	}
	
	
	
	
	
	

}
