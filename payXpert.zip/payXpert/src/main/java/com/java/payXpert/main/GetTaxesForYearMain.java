package com.java.payXpert.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.payXpert.dao.ITaxService;
import com.java.payXpert.dao.TaxService;
import com.java.payXpert.exception.InvalidInputException;
import com.java.payXpert.model.Tax;

public class GetTaxesForYearMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the tax year : ");
		String year = sc.next();
		ITaxService ts = new TaxService();
		try {
			List<Tax> taxList = ts.GetTaxesForYear(year);
			if(taxList.size() == 0)
				throw new InvalidInputException("Input data is invalid");
			else
			{
				for(Tax tax : taxList)
					System.out.println(tax);
			}
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} 
		catch (InvalidInputException e) {
			System.err.println(e.getMessage());
		}
		

	}

}
