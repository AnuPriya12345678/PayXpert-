package com.java.payXpert.main;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.java.payXpert.dao.EmployeeService;
import com.java.payXpert.dao.IEmployeeService;
import com.java.payXpert.exception.EmployeeNotFoundException;
import com.java.payXpert.model.Employee;

public class GetEmployeeByIdMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the employee id");
		int employeeId = -1;
		try {
			employeeId = sc.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.err.println("Expected input type was integer");
			System.exit(1);
		}
		IEmployeeService es = new EmployeeService();
		try {
			Employee employee = es.GetEmployeeById(employeeId);
			if(employee != null)
				System.out.println(employee);
			else
				throw new EmployeeNotFoundException("There is no employee having employee Id as "+employeeId);
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} 
		catch (EmployeeNotFoundException e) {
			System.err.println(e.getMessage());
		}
		
	}

}
