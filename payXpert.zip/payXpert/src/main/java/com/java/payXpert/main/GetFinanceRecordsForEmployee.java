package com.java.payXpert.main;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.java.payXpert.dao.FinancialRecordService;
import com.java.payXpert.dao.IFinancialRecordService;
import com.java.payXpert.exception.EmployeeNotFoundException;
import com.java.payXpert.model.FinancialRecord;

public class GetFinanceRecordsForEmployee {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the employee id");
		int employeeId = -1;
		try{
			employeeId = sc.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.err.println("Expected input type was integer");
			System.exit(1);
		}
		IFinancialRecordService fs = new FinancialRecordService();
		try {
			List<FinancialRecord> financialRecordList  = fs.GetFinancialRecordsForEmployee(employeeId);
			if(financialRecordList.size() == 0)
				throw new EmployeeNotFoundException("There is no employee having employeeId as "+employeeId);
			else {
				{
					for(FinancialRecord financialRecord : financialRecordList)
						System.out.println(financialRecord);
				}
			}
			
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} catch (EmployeeNotFoundException e) {
			System.err.println(e.getMessage());
		}
		
	}

}
