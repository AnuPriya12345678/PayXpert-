package com.java.payXpert.main;

import java.util.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

import com.java.payXpert.dao.FinancialRecordService;
import com.java.payXpert.dao.IFinancialRecordService;
import com.java.payXpert.exception.FinancialRecordException;
import com.java.payXpert.model.FinancialRecord;

public class GetFinancialRecordsForDateMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the date in the format yyyy-MM-dd");
		String dateStr = sc.next();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");  
		Date date = null;
		try {
			 date =   sdf.parse(dateStr);
		} 
		catch (ParseException e) {
			e.printStackTrace();
			System.exit(1);
		}  
		IFinancialRecordService fs = new FinancialRecordService();
		try {
			List<FinancialRecord> financialRecordList  = fs.GetFinancialRecordsForDate(date);
			if(financialRecordList.size() == 0)
				throw new FinancialRecordException("Record not found in financial management database");
			else {
					for(FinancialRecord financialRecord : financialRecordList)
						System.out.println(financialRecord);
				 }
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();    
		
       } catch (FinancialRecordException e) {
    	   System.err.println(e.getMessage());
		}   
	}
}


