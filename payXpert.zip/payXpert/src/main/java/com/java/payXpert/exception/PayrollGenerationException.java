package com.java.payXpert.exception;

public class PayrollGenerationException extends Exception {

	public PayrollGenerationException(String message) {
		super(message);
	}
	
}
