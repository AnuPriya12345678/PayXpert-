package com.java.payXpert.main;

import java.sql.SQLException;
import java.util.List;

import com.java.payXpert.dao.EmployeeService;
import com.java.payXpert.dao.IEmployeeService;
import com.java.payXpert.model.Employee;

public class GetAllEmployees {

	public static void main(String[] args) {
		
		IEmployeeService es = new EmployeeService();
		try {
			List<Employee> employeeList = es.GetAllEmployees();
			for(Employee employee : employeeList)
				System.out.println(employee);
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}		
	}

}
