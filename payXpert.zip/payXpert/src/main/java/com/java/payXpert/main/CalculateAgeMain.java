package com.java.payXpert.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import com.java.payXpert.model.Employee;

public class CalculateAgeMain {
	
	public static void main(String[] args) throws ParseException {
		Scanner sc = new Scanner(System.in);
		
		Employee employee = new Employee();
		System.out.println("Enter dob : ");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dobStr = sc.next();
	    Date dob = sdf.parse(dobStr);
	    System.out.println("Age is : "+ employee.CalculateAge(dob));
	}
}
