package com.java.payXpert.dao;

import java.util.Date;
import java.sql.SQLException;
import java.util.List;

import com.java.payXpert.model.Payroll;

public interface IPayrollService {
	
    Payroll GeneratePayRoll (int employeeId, Date startDate, Date endDate) throws ClassNotFoundException, SQLException;
	Payroll GetPayrollById(int payrollId) throws ClassNotFoundException, SQLException;
	List<Payroll> GetPayrollsForEmployee (int employeeId) throws ClassNotFoundException, SQLException;
	List<Payroll> GetPayroolsForPeriod(Date startDate, Date endDate) throws ClassNotFoundException, SQLException;
	
}
