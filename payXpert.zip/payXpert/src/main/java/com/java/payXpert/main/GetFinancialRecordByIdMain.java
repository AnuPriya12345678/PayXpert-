package com.java.payXpert.main;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.java.payXpert.dao.FinancialRecordService;
import com.java.payXpert.dao.IFinancialRecordService;
import com.java.payXpert.exception.FinancialRecordException;
import com.java.payXpert.model.FinancialRecord;



public class GetFinancialRecordByIdMain {

	public static void main(String[] args)  {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the record id");
		int recordId = -1;
		try{
			recordId = sc.nextInt();
		}
		catch(InputMismatchException e)
		{
			System.err.println("Expected input type was integer");
			System.exit(1);
		}
		IFinancialRecordService fs = new FinancialRecordService();
		try {
			FinancialRecord financialRecord  = fs.GetFinancialRecordById(recordId);
			if(financialRecord != null)
				System.out.println(financialRecord);
			else
				throw new FinancialRecordException("Record not found in financial management database");
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} 
		catch (FinancialRecordException e) {
			System.err.println(e.getMessage());
		}

	}

}
