package com.java.payXpert.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.payXpert.dao.FinancialRecordService;
import com.java.payXpert.dao.IFinancialRecordService;

public class AddFinancialRecordMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the employeeId : ");
		int employeeId = sc.nextInt();
		System.out.println("Enter description : ");
		String description = sc.next();
		System.out.println("Enter amount : ");
		Double amount = sc.nextDouble();
		System.out.println("Enter record type : ");
		String recordType = sc.next();
		IFinancialRecordService financialRecord = new FinancialRecordService();
		try {
			String msg = financialRecord.AddFinancialRecord(employeeId, description, amount, recordType);
	        System.out.println(msg);
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

}
