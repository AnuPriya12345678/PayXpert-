package com.java.payXpert.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.payXpert.model.Employee;
import com.java.payXpert.util.DBConnUtil;
import com.java.payXpert.util.DBPropertyUtil;



public class EmployeeService implements IEmployeeService {
	
	Connection con;
	PreparedStatement pst;

	@Override
	public Employee GetEmployeeById(int employeeId) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM employee WHERE employeeId = ?";
		pst = con.prepareStatement(query);
		pst.setInt(1, employeeId);
		ResultSet rs = pst.executeQuery();
		Employee employee = null;
		if(rs.next())
		{
			employee = new Employee();
			employee.setEmployeeId(rs.getInt("EmployeeId"));  
			employee.setFirstName(rs.getString("firstName"));
			employee.setLastName(rs.getString("LastName"));
			employee.setDob(rs.getDate("dob"));
			employee.setGender(rs.getString("gender"));
			employee.setEmail(rs.getString("email"));
			employee.setPhoneNumber(rs.getString("phoneNumber"));
			employee.setAddress(rs.getString("address"));
			employee.setPosition(rs.getString("position"));
			employee.setJoiningDate(rs.getDate("joiningDate"));
			employee.setTerminationDate(rs.getDate("terminationDate"));
		}
		return employee;
			
	}

	@Override
	public List<Employee> GetAllEmployees() throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM employee";
		pst = con.prepareStatement(query);
		ResultSet rs = pst.executeQuery();
		List<Employee> employeeList = new ArrayList<Employee> ();
		Employee employee = null;
		while(rs.next())
		{
			employee = new Employee();
			employee.setEmployeeId(rs.getInt("EmployeeId"));  
			employee.setFirstName(rs.getString("firstName"));
			employee.setLastName(rs.getString("LastName"));
			employee.setDob(rs.getDate("dob"));
			employee.setGender(rs.getString("gender"));
			employee.setEmail(rs.getString("email"));
			employee.setPhoneNumber(rs.getString("phoneNumber"));
			employee.setAddress(rs.getString("address"));
			employee.setPosition(rs.getString("position"));
			employee.setJoiningDate(rs.getDate("joiningDate"));
			employee.setTerminationDate(rs.getDate("terminationDate"));
			employeeList.add(employee);
		}
		return employeeList;
		
	}

	@Override
	public String AddEmployee(Employee employee) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "INSERT INTO employee VALUES (?,?,?,?,?,?,?,?,?,?,?)";
		pst = con.prepareStatement(query);
		pst.setInt(1, employee.getEmployeeId());
		pst.setString(2, employee.getFirstName());
		pst.setString(3, employee.getLastName());
		pst.setDate(4, new java.sql.Date(employee.getDob().getTime()));
		pst.setString(5, employee.getGender());
		pst.setString(6, employee.getEmail());
		pst.setString(7, employee.getPhoneNumber());
		pst.setString(8, employee.getAddress());
		pst.setString(9, employee.getPosition());
		pst.setDate(10, new java.sql.Date(employee.getJoiningDate().getTime()));
		pst.setDate(11, new java.sql.Date(employee.getTerminationDate().getTime()));
	    pst.executeUpdate();
		return "Employee Added ... ";
		
	}

	@Override
	public String UpdateEmployee(Employee employee) throws ClassNotFoundException, SQLException {
		
		if(GetEmployeeById(employee.getEmployeeId()) != null)
		{
			String connectionString = DBPropertyUtil.getConnectonString("db");
			con = DBConnUtil.getConnection(connectionString);
			String query = "UPDATE employee SET firstName=?, lastName=?, dob=?, gender=?, email=?, phoneNumber=?, address=?, position=?, joiningDate=?, terminationDate=? WHERE employeeId=? ";
			pst = con.prepareStatement(query);
			pst.setString(1, employee.getFirstName());
			pst.setString(2, employee.getLastName());
			pst.setDate(3, new java.sql.Date(employee.getDob().getTime()));
			pst.setString(4, employee.getGender());
			pst.setString(5, employee.getEmail());
			pst.setString(6, employee.getPhoneNumber());
			pst.setString(7, employee.getAddress());
			pst.setString(8, employee.getPosition());
			pst.setDate(9, new java.sql.Date(employee.getJoiningDate().getTime()));
			pst.setDate(10, new java.sql.Date(employee.getTerminationDate().getTime()));
			pst.setInt(11, employee.getEmployeeId());
		    pst.executeUpdate();
			return "Employee Updated ... ";
		}
		else
			return "Invalid employee Id";
		
	}

	@Override
	public String RemoveEmployee(int employeeId) throws ClassNotFoundException, SQLException {
		
		if(GetEmployeeById(employeeId) != null)
		{
			String connectionString = DBPropertyUtil.getConnectonString("db");
			con = DBConnUtil.getConnection(connectionString);
			String query = "DELETE FROM employee WHERE employeeId = ?";
			pst = con.prepareStatement(query);
			pst.setInt(1, employeeId);
			pst.executeUpdate();
			return "Employee Deleted ...";
		}
		else
			return "Invalid employee Id";
	}
	
	

}
