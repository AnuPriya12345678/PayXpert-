package com.java.payXpert.model;

import java.time.Year;
import java.util.Objects;

public class Tax {

	private int taxId;
	private int employeeId;
	private String taxYear;
	private Double taxableIncome;
	private Double taxAmount;
	
	public Tax() {
		
	}

	public Tax(int taxId, int employeeId, String taxYear, Double taxableIncome, Double taxAmount) {
		super();
		this.taxId = taxId;
		this.employeeId = employeeId;
		this.taxYear = taxYear;
		this.taxableIncome = taxableIncome;
		this.taxAmount = taxAmount;
	}

	public int getTaxId() {
		return taxId;
	}

	public void setTaxId(int taxId) {
		this.taxId = taxId;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getTaxYear() {
		return taxYear;
	}

	public void setTaxYear(String taxYear) {
		this.taxYear = taxYear;
	}

	public Double getTaxableIncome() {
		return taxableIncome;
	}

	public void setTaxableIncome(Double taxableIncome) {
		this.taxableIncome = taxableIncome;
	}

	public Double getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(Double taxAmount) {
		this.taxAmount = taxAmount;
	}

	@Override
	public String toString() {
		return "Tax [taxId=" + taxId + ", employeeId=" + employeeId + ", taxYear=" + taxYear + ", taxableIncome="
				+ taxableIncome + ", taxAmount=" + taxAmount + "]";
	}
	
	public int hashCode()
	{
		return Objects.hash(taxId, employeeId, taxYear, taxableIncome, taxAmount);
	}
	
	public boolean equals(Object obj)
	{
		Tax tax = (Tax) obj;
		if(tax.getTaxId() == taxId && tax.getEmployeeId() == employeeId 
				&& tax.getTaxYear() == taxYear
				&& Double.compare(tax.getTaxableIncome(), taxableIncome) == 0
				&& Double.compare(tax.getTaxAmount(), taxAmount) == 0
			)
		{
			return true;
		}
		return false;
	}
}
