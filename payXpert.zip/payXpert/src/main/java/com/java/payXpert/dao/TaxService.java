package com.java.payXpert.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.payXpert.model.Payroll;
import com.java.payXpert.model.Tax;
import com.java.payXpert.util.DBConnUtil;
import com.java.payXpert.util.DBPropertyUtil;

public class TaxService implements ITaxService {
	
	Connection con;
	PreparedStatement pst;

	@Override
	public Tax GetTaxById(int taxId) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM tax WHERE taxId = ?";
		pst = con.prepareStatement(query);
		pst.setInt(1, taxId);
		ResultSet rs = pst.executeQuery();
		Tax tax = null;
		if(rs.next())
		{
			tax = new Tax();
			tax.setTaxId(rs.getInt("taxId"));
			tax.setEmployeeId(rs.getInt("employeeId"));
			tax.setTaxYear(rs.getString("taxYear").split("-")[0]);
			tax.setTaxableIncome(rs.getDouble("taxableIncome"));
			tax.setTaxAmount(rs.getDouble("taxAmount"));	
		}
		return tax;
		
	}

	@Override
	public List<Tax> GetTaxesForEmployee(int employeeId) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM tax WHERE employeeId = ?";
		pst = con.prepareStatement(query);
		pst.setInt(1, employeeId);
		ResultSet rs = pst.executeQuery();
		List<Tax> taxList = new ArrayList<Tax> ();
		Tax tax = null;
		while(rs.next())
		{
			tax = new Tax();
			tax.setTaxId(rs.getInt("taxId"));
			tax.setEmployeeId(rs.getInt("employeeId"));
			tax.setTaxYear(rs.getString("taxYear").split("-")[0]);
			tax.setTaxableIncome(rs.getDouble("taxableIncome"));
			tax.setTaxAmount(rs.getDouble("taxAmount"));	
			taxList.add(tax);
		}
		return taxList;
		
	}

	@Override
	public List<Tax> GetTaxesForYear(String taxYear) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query = "SELECT * FROM tax WHERE taxYear = ?";
		pst = con.prepareStatement(query);
		pst.setString(1, taxYear);
		ResultSet rs = pst.executeQuery();
		List<Tax> taxList = new ArrayList<Tax> ();
		Tax tax = null;
		while(rs.next())
		{
			tax = new Tax();
			tax.setTaxId(rs.getInt("taxId"));
			tax.setEmployeeId(rs.getInt("employeeId"));
			tax.setTaxYear(rs.getString("taxYear").split("-")[0]);
			tax.setTaxableIncome(rs.getDouble("taxableIncome"));
			tax.setTaxAmount(rs.getDouble("taxAmount"));	
			taxList.add(tax);
		}
		return taxList;
		
	}

	@Override
	public Double CalculateTax(int employeeId, String taxYear) throws ClassNotFoundException, SQLException {
		
		String connectionString = DBPropertyUtil.getConnectonString("db");
		con = DBConnUtil.getConnection(connectionString);
		String query1 = "SELECT netSalary FROM payroll WHERE employeeId = ?";
		pst = con.prepareStatement(query1);
		pst.setInt(1, employeeId);
		ResultSet rs = pst.executeQuery();
		Payroll payroll = null;
		if(rs.next())
		{
			payroll = new Payroll();
			payroll.setNetSalary(rs.getDouble("netSalary"));
		}
		String query2 = "SELECT taxableIncome FROM tax WHERE employeeId = ? AND taxYear = ?";
		pst = con.prepareStatement(query2);
		pst.setInt(1, employeeId);
		pst.setString(2, taxYear);
		rs = pst.executeQuery();
		Tax tax = null;
		if(rs.next())
		{
			tax = new Tax();
			tax.setTaxableIncome(rs.getDouble("taxableIncome"));
		}
		if(payroll == null || tax == null)
			return -1.0;
		return  payroll.getNetSalary() - tax.getTaxableIncome();
	}
}
