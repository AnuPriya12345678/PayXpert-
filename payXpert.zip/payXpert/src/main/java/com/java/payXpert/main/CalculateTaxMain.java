package com.java.payXpert.main;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.java.payXpert.dao.ITaxService;
import com.java.payXpert.dao.TaxService;
import com.java.payXpert.exception.TaxCalculationException;

public class CalculateTaxMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the employeeId : ");
		int employeeId = -1;
		try{
			employeeId = sc.nextInt();
		}
		catch(InputMismatchException e){
			System.err.println("Expected input type was integer");
			System.exit(1);
		}
		System.out.println("Enter tax year : ");
		String taxYear = sc.next();
		ITaxService ts = new TaxService();
		Double tax = 0.0;
		try {
			tax = ts.CalculateTax(employeeId, taxYear);
			if(tax == -1.0)
				throw new TaxCalculationException("Tax cannot be calculated");
			System.out.println(tax);
		} 
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} 
		catch (TaxCalculationException e) {
			System.err.println(e.getMessage());
		}
		
	}

}
