package com.java.payXpert.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.payXpert.model.Employee;

public interface IEmployeeService {
	
	Employee GetEmployeeById(int employeeId) throws ClassNotFoundException, SQLException;
	List<Employee> GetAllEmployees() throws ClassNotFoundException, SQLException;
	String AddEmployee(Employee employee) throws ClassNotFoundException, SQLException;
	String UpdateEmployee(Employee employee) throws ClassNotFoundException, SQLException;
	String RemoveEmployee(int employeeId) throws ClassNotFoundException, SQLException;
	
}
